#!/bin/bash
cd live && python3 -m http.server 8080

