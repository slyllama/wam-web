#!/bin/bash
aws s3 sync --delete live s3://hoseshop.slyllama.net

